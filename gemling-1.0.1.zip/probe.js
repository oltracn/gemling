(function() {
  let overrideConvId = null;
  window.addEventListener('gemling-set-override-convid', (e) => {
    overrideConvId = e.detail.convId;
  });

  let overrideDeleteData = null;
  window.addEventListener('gemling-set-override-delete', (e) => {
    overrideDeleteData = e.detail;
  });

  window.addEventListener('gemling-request-conv-id', () => {
    function findConvId(obj, depth = 0, seen = new Set()) {
      if (depth > 15 || !obj || typeof obj !== 'object' || seen.has(obj)) return null;
      seen.add(obj);

      // Check common property names first
      if (!Array.isArray(obj)) {
        for (const key of ['id', 'conversationId', 'name', 'chatId']) {
          try {
            const val = obj[key];
            if (typeof val === 'string') {
              if (val.startsWith('c_') && val.length > 5) return val;
              if (/^[0-9a-zA-Z_-]{12,25}$/.test(val)) return val;
            }
          } catch(e) {}
        }
      }

      if (Array.isArray(obj)) {
        for (let i = 0; i < obj.length; i++) {
          const item = obj[i];
          if (typeof item === 'string') {
            if (item.startsWith('c_') && item.length > 5) return item;
            if (/^[0-9a-f]{16}$/i.test(item)) return item;
          }
          const res = findConvId(item, depth + 1, seen);
          if (res) return res;
        }
      } else {
        for (const key in obj) {
          try {
            const item = obj[key];
            if (typeof item === 'string') {
              if (item.startsWith('c_') && item.length > 5) return item;
              if (/^[0-9a-f]{16}$/i.test(item)) return item;
            }
            const res = findConvId(item, depth + 1, seen);
            if (res) return res;
          } catch(e) {}
        }
      }
      return null;
    }

    const snippets = document.querySelectorAll('search-snippet:not([data-gemling-conv-id]), search-zero-state .conversation-container:not([data-gemling-conv-id])');
    snippets.forEach((snippet, index) => {
      let id = null;
      if (snippet.__ngContext__) {
        id = findConvId(snippet.__ngContext__);
      }
      if (!id && window.ng) {
        try {
          const comp = window.ng.getComponent(snippet);
          id = findConvId(comp);
        } catch(e) {}
      }
      if (id) {
        snippet.setAttribute('data-gemling-conv-id', id);
      } else {
        // Fallback to a dummy ID so the checkbox at least renders.
        // We will extract the index from jslog if possible to give it a unique pseudo-id.
        let pseudoId = 'not-found-' + Date.now() + '-' + index;
        try {
           const jslog = snippet.querySelector('[jslog]')?.getAttribute('jslog');
           if (jslog) {
             const match = jslog.match(/\[(\d+),null,0\]/);
             if (match) pseudoId = 'search-result-' + match[1];
           }
        } catch(e) {}
        snippet.setAttribute('data-gemling-conv-id', pseudoId);
      }
      window.dispatchEvent(new CustomEvent('gemling-conv-id-ready'));
    });
  });

  const originalOpen = XMLHttpRequest.prototype.open;
  const originalSend = XMLHttpRequest.prototype.send;

  XMLHttpRequest.prototype.open = function(method, url, ...rest) {
    this._gemlingMethod = method;
    this._gemlingUrl = typeof url === 'string' ? url : '';
    return originalOpen.apply(this, [method, url, ...rest]);
  };

  XMLHttpRequest.prototype.send = function(body) {
    if (this._gemlingMethod?.toUpperCase() === 'POST' && this._gemlingUrl.includes('batchexecute')) {
      try {
        let bodyText = typeof body === 'string' ? body : '';
        const urlMatch = this._gemlingUrl.match(/source-path=([^&]+)/);
        const sourcePathRaw = urlMatch ? urlMatch[1] : '';

        if (this._gemlingUrl.includes('MUAZcd')) {
          const params = new URLSearchParams(bodyText);
          const fReq = params.get('f.req');
          const at = params.get('at');

          if (fReq && at) {
            const parsed = JSON.parse(fReq);
            const innerStr = parsed[0][0][1];
            const inner = JSON.parse(innerStr);
            const notebookPath = inner[2][7];
            let convId = inner[2][0];

            if (overrideConvId) {
              inner[2][0] = overrideConvId;
              parsed[0][0][1] = JSON.stringify(inner);
              params.set('f.req', JSON.stringify(parsed));
              bodyText = params.toString();
              body = bodyText; 
              convId = overrideConvId; 
              overrideConvId = null; 
            }

            window.dispatchEvent(new CustomEvent('gemling-api-captured', {
              detail: {
                url: this._gemlingUrl,
                sourcePathRaw: sourcePathRaw,
                at: at,
                notebookPath: notebookPath,
                convId: convId,
                fReqTemplate: innerStr,
                bodyTemplate: bodyText
              }
            }));
          }
        } else {
          if (overrideDeleteData && bodyText.includes(overrideDeleteData.original)) {
            bodyText = bodyText.replace(new RegExp(overrideDeleteData.original, 'g'), overrideDeleteData.target);
            body = bodyText;
            overrideDeleteData = null;
          }

          window.dispatchEvent(new CustomEvent('gemling-api-captured-raw', {
            detail: {
              url: this._gemlingUrl,
              sourcePathRaw: sourcePathRaw,
              bodyTemplate: bodyText
            }
          }));
        }
      } catch(e) {
        console.error('[Gemling] parse error:', e);
      }
    }
    return originalSend.apply(this, arguments);
  };
})();
